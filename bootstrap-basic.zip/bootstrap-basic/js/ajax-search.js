jQuery(document).ready(function($) {
    const searchInput = $('#ajax-search-input');
    const resultsContainer = $('#search-results');

    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    function fetchResults() {
        const keywords = searchInput.val().trim();
        if (keywords.length >= 3) {

            $.ajax({
                url: ajax_search_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'ajax_search',
                    search: searchInput.val()
                },
                success: function(response) {
                    if (response.success) {
                        resultsContainer.html(response.data.results);
                    } else {
                        resultsContainer.html('<p>No results found.</p>');
                    }
                },
                error: function() {
                    resultsContainer.html('<p>An error occurred while searching.</p>');
                }
            });
        } else {
            resultsContainer.empty();
        }
    }

    const debouncedFetchResults = debounce(fetchResults, 300); // 300ms debounce time

    searchInput.on('input', debouncedFetchResults);
});
