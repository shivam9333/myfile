<?php
/**
 * The theme footer
 * 
 * @package bootstrap-basic
 */
?>

            </div><!--.site-content-->
            
            
            <footer id="site-footer" role="contentinfo">
                <div id="footer-row" class="row site-footer">
                    <div class="col-md-6 footer-left">
                        <?php 
                        if (!dynamic_sidebar('footer-left')) {
                            /* translators: %s WordPress with link. */
                            printf(__('Powered by %s', 'bootstrap-basic'), '<a href="https://wordpress.org" rel="nofollow">WordPress</a>');
                            echo ' | ';
                            /* translators: %s Bootstrap Basic with link. */
                            printf(__('Theme: %s', 'bootstrap-basic'), '<a href="https://rundiz.com" rel="nofollow">Bootstrap Basic</a>');
                        } 
                        ?> 
                    </div>
                    <div class="col-md-6 footer-right text-right">
                        <?php dynamic_sidebar('footer-right'); ?> 
                    </div>
                </div>
            </footer>
        </div><!--.container page-container-->
        
        
        <!--wordpress footer-->
        <?php wp_footer(); ?> 
        <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.querySelector('#ajax-search-input');
            const resultsContainer = document.querySelector('#search-results');

            function debounce(func, wait) {
                let timeout;
                return function(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }

            function fetchResults() {
                const keywords = searchInput.value.trim().split(/\s+/);
                if (keywords.length >= 3) {
                    const data = {
                        'action': 'ajax_search',
                        'search': searchInput.value
                    };
                    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams(data).toString()
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            resultsContainer.innerHTML = data.data.results;
                        } else {
                            resultsContainer.innerHTML = '<p>No results found.</p>';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        resultsContainer.innerHTML = '<p>An error occurred while searching.</p>';
                    });
                } else {
                    resultsContainer.innerHTML = '';
                }
            }

            const debouncedFetchResults = debounce(fetchResults, 300); // 300ms debounce time

            if (searchInput) {
                searchInput.addEventListener('input', debouncedFetchResults);
            }
        });
    </script>
    </body>
</html>
