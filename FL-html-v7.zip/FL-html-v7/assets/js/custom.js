$(document).ready(function(){
  var headerHeight = $('header').outerHeight();
  if($(window).width() < 780 ){
    headerHeight = headerHeight + 40;
    $('.headerText').css('top', headerHeight + 'px');
  } else {
    headerHeight = headerHeight - 40;
    $('.headerText').css('top', headerHeight + 'px');
  }

  $('.section_with_slider .owl-carousel').owlCarousel({
      center: true,
	  smartSpeed: 1500,
      animateIn: 'linear',
      animateOut: 'linear',
      loop:true,
      margin:15,
      nav:true,
      navText: ['<div class="prevSlide slideBtns"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M13.602 14.4626L9.14922 10.0001L13.602 5.53758L12.2312 4.16675L6.39783 10.0001L12.2312 15.8334L13.602 14.4626Z" fill="#454545"/></svg></div>', '<div class="nextSlide slideBtns"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M6.39783 14.4626L10.8506 10.0001L6.39783 5.53758L7.76866 4.16675L13.602 10.0001L7.76866 15.8334L6.39783 14.4626Z" fill="#454545"/></svg></div>'],
      dots: false,
      responsiveClass:true,
      responsive:{
        0:{
          items:1
        },
        600:{
          items:2
        },
        1000:{
          items:2
        }
      }
  });

  $('.global_faculty_section .owl-carousel').owlCarousel({
      loop:true,
      margin:0,
      nav:false,
      items:1,
      autoplay:true,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
  });

  
  $('#header_banner_slider').owlCarousel({
      loop:true,
      margin:0,
      nav:false,
      items:1,
      dots: false,
      autoplay:true,
  });
  
  $('#Insights_mobile_slider').owlCarousel({
      loop:true,
      margin:15,
      nav:false,
      dots: false,
      items:1
  });

  //code to check if element is visible in viewport
  if ($('.counter-box').length > 0) {
    var animateElement = $('.counter-box');
    $.fn.isOnScreen = function () {
      var win = $(window);
      var viewport = {
        top: win.scrollTop(),
        left: win.scrollLeft()
      };
      viewport.right = viewport.left + win.width();
      viewport.bottom = viewport.top + win.height();
      var bounds = this.offset();
      bounds.right = bounds.left + this.outerWidth();
      bounds.bottom = bounds.top + this.outerHeight();
      return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));
    };
  }
	$(window).scroll(function () {
    if ($('.counter-box').length > 0) {
      if (animateElement.isOnScreen()) {
        if(!animateElement.hasClass('animate__animated')) { 
          animateElement.addClass("animate__animated animate__fadeInLeft");
        }
      }
    }
	});
	
	/*footer address toggle*/
	$('.responsive-caption').click(function () {
		if($(this).hasClass("opened")){
			$(this).removeClass("opened");
			$(this).addClass("closed");
		}else{
			$(this).removeClass("closed");
			$(this).addClass("opened");
		}
		$(this).parent().find('.responsive-content').slideToggle(500);
	});
	
	/*footer menu toggle*/
	$('.footer-menu .menu-item-list').click(function () {
		if($(this).hasClass("opened")){
			$(this).removeClass("opened");
			$(this).addClass("closed");
		}else{
			$(this).removeClass("closed");
			$(this).addClass("opened");
		}
		$(this).find('.sub-menu-box').slideToggle(500);
	});

  /** Discover Menus */
  $('#topHeaderNav').click(function(){
    $('.top_header_discoverMenus').toggleClass("show");
});

});