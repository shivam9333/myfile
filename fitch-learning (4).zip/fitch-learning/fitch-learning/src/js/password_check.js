<script>
  // Mock function to check password history
  function checkPasswordHistory(password) {
    // Implement your logic to check the password history
    // For demonstration, let's assume no recent passwords match
    return true;
  }

  document.getElementById('password').addEventListener('input', function () {
    const password = this.value;

    // Check minimum length
    if (password.length >= 12) {
      document.getElementById('length').classList.remove('text-grey');
      document.getElementById('length').classList.add('text-green');
    } else {
      document.getElementById('length').classList.remove('text-green');
      document.getElementById('length').classList.add('text-grey');
    }

    // Check maximum length
    if (password.length <= 255) {
      document.getElementById('maxlength').classList.remove('text-grey');
      document.getElementById('maxlength').classList.add('text-green');
    } else {
      document.getElementById('maxlength').classList.remove('text-green');
      document.getElementById('maxlength').classList.add('text-grey');
    }

    // Check lowercase characters
    if (/[a-z]/.test(password)) {
      document.getElementById('lowercase').classList.remove('text-grey');
      document.getElementById('lowercase').classList.add('text-green');
    } else {
      document.getElementById('lowercase').classList.remove('text-green');
      document.getElementById('lowercase').classList.add('text-grey');
    }

    // Check uppercase characters
    if (/[A-Z]/.test(password)) {
      document.getElementById('uppercase').classList.remove('text-grey');
      document.getElementById('uppercase').classList.add('text-green');
    } else {
      document.getElementById('uppercase').classList.remove('text-green');
      document.getElementById('uppercase').classList.add('text-grey');
    }

    // Check password history (mock function)
    if (checkPasswordHistory(password)) {
      document.getElementById('norepeat').classList.remove('text-grey');
      document.getElementById('norepeat').classList.add('text-green');
    } else {
      document.getElementById('norepeat').classList.remove('text-green');
      document.getElementById('norepeat').classList.add('text-grey');
    }
  });
</script>
