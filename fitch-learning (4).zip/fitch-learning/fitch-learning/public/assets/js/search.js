function showSuggestions() {
    const searchInput = document.getElementById('searchInput').value;
    const recentSearches = document.getElementById('recentSearches');
    const suggestions = document.getElementById('suggestions');
    const loader = document.getElementById('loader');
    const searchResults = document.getElementById('searchResults');
    const seeAllResultsButton = document.getElementById('seeAllResultsButton');
    const cancelButton = document.getElementById('cancelButton');
    const crossButton = document.getElementById('crossButton');

    if (searchInput.length > 0) {
        recentSearches.classList.add('d-none');
        suggestions.classList.add('d-none');
        loader.classList.remove('d-none');
        cancelButton.classList.add('d-none');
        crossButton.classList.remove('d-none');

        setTimeout(() => {
            loader.classList.add('d-none');
            searchResults.classList.remove('d-none');
            seeAllResultsButton.classList.remove('d-none');

            document.getElementById('otherResults').innerHTML = `
                <a href="#" class="list-group-item list-group-item-action">Asia Financial Report 2022</a>
                <a href="#" class="list-group-item list-group-item-action">Financial Model Summary</a>
            `;
            document.getElementById('courseResults').innerHTML = `
                <a href="#" class="list-group-item list-group-item-action">Financial Modelling Course</a>
                <a href="#" class="list-group-item list-group-item-action">Corporate Finance Fundamentals</a>
                <a href="#" class="list-group-item list-group-item-action">Financial Accounting Fundamentals</a>
                <a href="#" class="list-group-item list-group-item-action">Financial Analysis and Valuation</a>
            `;
            document.getElementById('insightResults').innerHTML = `
                <a href="#" class="list-group-item list-group-item-action">Leveraging Python and Financial Data Analytics for Success</a>
                <a href="#" class="list-group-item list-group-item-action">ESG Ratings, Data and Analysis: Enhancing your Skills</a>
                <a href="#" class="list-group-item list-group-item-action">Enhancing Forecasting with Machine Learning</a>
            `;
        }, 1000);
    } else {
        recentSearches.classList.remove('d-none');
        suggestions.classList.remove('d-none');
        loader.classList.add('d-none');
        searchResults.classList.add('d-none');
        seeAllResultsButton.classList.add('d-none');
        cancelButton.classList.remove('d-none');
        crossButton.classList.add('d-none');
    }
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    showSuggestions();
}

function seeAllResults() {
    alert("See All Results Clicked");
}
